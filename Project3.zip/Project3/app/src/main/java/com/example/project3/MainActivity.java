package com.example.project3;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText etItemName, etItemQty, etPhone;
    Button btnAddItem, btnSendSms;
    RecyclerView recyclerView;

    DatabaseHelper db;
    ArrayList<Integer> ids, quantities;
    ArrayList<String> names;
    ItemAdapter adapter;

    ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    sendSmsMessage();
                } else {
                    Toast.makeText(this, "SMS permission denied. App still works without SMS.", Toast.LENGTH_LONG).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etItemName = findViewById(R.id.etItemName);
        etItemQty = findViewById(R.id.etItemQty);
        etPhone = findViewById(R.id.etPhone);
        btnAddItem = findViewById(R.id.btnAddItem);
        btnSendSms = findViewById(R.id.btnSendSms);
        recyclerView = findViewById(R.id.recyclerView);

        db = new DatabaseHelper(this);

        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        btnAddItem.setOnClickListener(v -> {
            String name = etItemName.getText().toString().trim();
            String qtyText = etItemQty.getText().toString().trim();

            if (name.isEmpty() || qtyText.isEmpty()) {
                Toast.makeText(this, "Enter item name and quantity", Toast.LENGTH_SHORT).show();
                return;
            }

            int qty = Integer.parseInt(qtyText);
            boolean inserted = db.addItem(name, qty);

            if (inserted) {
                Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show();
                etItemName.setText("");
                etItemQty.setText("");
                loadItems();
            } else {
                Toast.makeText(this, "Failed to add item", Toast.LENGTH_SHORT).show();
            }
        });

        btnSendSms.setOnClickListener(v -> checkSmsPermission());

        loadItems();
    }

    private void loadItems() {
        ids = new ArrayList<>();
        names = new ArrayList<>();
        quantities = new ArrayList<>();

        Cursor cursor = db.getAllItems();

        while (cursor.moveToNext()) {
            ids.add(cursor.getInt(0));
            names.add(cursor.getString(1));
            quantities.add(cursor.getInt(2));
        }

        cursor.close();

        adapter = new ItemAdapter(this, ids, names, quantities, this::loadItems);
        recyclerView.setAdapter(adapter);
    }

    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            sendSmsMessage();
        } else {
            requestPermissionLauncher.launch(Manifest.permission.SEND_SMS);
        }
    }

    private void sendSmsMessage() {
        String phone = etPhone.getText().toString().trim();

        if (phone.isEmpty()) {
            Toast.makeText(this, "Enter a phone number", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phone, null, "Inventory alert from your app.", null, null);
            Toast.makeText(this, "SMS sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}