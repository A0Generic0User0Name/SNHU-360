package com.example.project3;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ItemViewHolder> {

    Context context;
    ArrayList<Integer> ids;
    ArrayList<String> names;
    ArrayList<Integer> quantities;
    DatabaseHelper db;
    Runnable refreshCallback;

    public ItemAdapter(Context context, ArrayList<Integer> ids, ArrayList<String> names,
                       ArrayList<Integer> quantities, Runnable refreshCallback) {
        this.context = context;
        this.ids = ids;
        this.names = names;
        this.quantities = quantities;
        this.refreshCallback = refreshCallback;
        this.db = new DatabaseHelper(context);
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_card, parent, false);
        return new ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        int id = ids.get(position);
        String name = names.get(position);
        int qty = quantities.get(position);

        holder.tvName.setText(name);
        holder.tvQty.setText("Qty: " + qty);

        holder.btnDelete.setOnClickListener(v -> {
            boolean deleted = db.deleteItem(id);
            if (deleted) {
                Toast.makeText(context, "Item deleted", Toast.LENGTH_SHORT).show();
                refreshCallback.run();
            }
        });

        holder.btnEdit.setOnClickListener(v -> showEditDialog(id, name, qty));
    }

    private void showEditDialog(int id, String oldName, int oldQty) {

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        View customView = LayoutInflater.from(context).inflate(R.layout.dialog_edit_item, null);
        builder.setView(customView);

        EditText etEditName = customView.findViewById(R.id.etEditName);
        EditText etEditQty = customView.findViewById(R.id.etEditQty);
        Button btnSaveEdit = customView.findViewById(R.id.btnSaveEdit);

        etEditName.setText(oldName);
        etEditQty.setText(String.valueOf(oldQty));

        AlertDialog dialog = builder.create();

        btnSaveEdit.setOnClickListener(v -> {
            String newName = etEditName.getText().toString().trim();
            String qtyText = etEditQty.getText().toString().trim();

            if (newName.isEmpty() || qtyText.isEmpty()) {
                Toast.makeText(context, "Fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            int newQty = Integer.parseInt(qtyText);
            boolean updated = db.updateItem(id, newName, newQty);

            if (updated) {
                Toast.makeText(context, "Item updated", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
                refreshCallback.run();
            }
        });

        dialog.show();
    }

    @Override
    public int getItemCount() {
        return ids.size();
    }

    public static class ItemViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvQty;
        Button btnEdit, btnDelete;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvName);
            tvQty = itemView.findViewById(R.id.tvQty);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}